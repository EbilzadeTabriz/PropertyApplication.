package www.Property.property.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateUserRequest(
        @Email(message = "Enter email") String email,
        @Size(min = 8,message ="Lenght of password will be at least 8") String password,
        @NotBlank(message = "User name shouldn't be empty") String username
) {
}
