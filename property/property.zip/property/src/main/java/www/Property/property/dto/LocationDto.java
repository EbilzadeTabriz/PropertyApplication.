package www.Property.property.dto;

public record LocationDto(String district,
                          String city,
                          String neighborhood


) {
}
