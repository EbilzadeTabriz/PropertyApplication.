package www.Property.property.dto;

public record Property1Dto(
        String title,
        Double price,
        String city,
        String distirict,
        Integer bedrooms,
        Integer bathroom,
        String contactInformation
) {
}
