package www.Property.property.dto;

public record PropertyImageDto(
        String property_images
) {
}
