package www.Property.property.dto;

public record PropertyTypeDto(String name,
                              String description,
                              String image) {
}
