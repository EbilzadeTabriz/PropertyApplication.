package www.Property.property.dto;

public record UserLoginDto(String email,
                           String password) {
}
