package www.Property.property.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.yaml.snakeyaml.introspector.Property;

import java.util.List;

@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Location")
public class Location {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @NotNull
    private Long locationId;
    @NotEmpty
    @NotEmpty
    @Column(name ="District",updatable = false)
    private String district;
    @NotEmpty
    @NotEmpty
    @Column(name= "City",updatable = false)
    private String city;
    @NotEmpty
    @NotBlank
    @Column(name = "Neighborhood",updatable = false)
    private String neighborhood;
    @OneToMany(mappedBy = "location")
    private List<Property> properties;
}
