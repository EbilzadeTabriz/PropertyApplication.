package www.Property.property.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;


import java.time.LocalDate;

@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Notification")
public class Notification {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @NotNull
    private Long notificationId;
    @NotNull
    @Column(name ="MessageSent")
    private LocalDate sentAt;
    @NotBlank
    @NotEmpty
    @Column(name ="Message")
    private String message;
    @ManyToOne
    @JoinColumn(name="user_id",referencedColumnName = "property_id")
    private User user;




}
