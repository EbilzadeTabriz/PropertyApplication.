package www.Property.property.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Property")
public class Property1 {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long propertyId;

    @NotEmpty
    @NotBlank
    @Column(name = "TEXT")
    private String title;
    @NotNull
    @Column(name = "Price")
    private Double price;

    @ManyToOne
    @JoinColumn(name = "user_id",referencedColumnName = "id")
    private User user;

    @NotEmpty
    @NotBlank
    @Column(name = "City")
    private String city;

    @NotEmpty
    @NotBlank
    @Column(name = "Distirict")
    private String distirict;

    @NotEmpty
    @NotBlank
    @Column(name = "bedrooms")
    private Integer bedrooms;
    @NotEmpty
    @NotBlank
    @Column(name = "Bathroom")
    private Integer bathroom;
    @ManyToOne
    @JoinColumn(name = "property_type_id")
    private PropertyType propertyType;
    @OneToMany
    private List<PropertyImage> images;
    @NotEmpty

    @NotBlank
    @Column(name = "ContactInformation")
    private String contactInformation;


}
