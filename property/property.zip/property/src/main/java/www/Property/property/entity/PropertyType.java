package www.Property.property.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@Entity
@Table(name ="PropertyType")
public class PropertyType {
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @NotNull
    @Id
    private Long propertyTypeId;
    @NotBlank
    @NotEmpty
    @Column(name="Name")
    private String name;
    @NotBlank
    @NotEmpty
    @Column(name = "Description")
    private String description;
    @Column(name = "Image")
    private String image;


}
