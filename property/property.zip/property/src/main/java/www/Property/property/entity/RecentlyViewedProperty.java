package www.Property.property.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;


@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Recently_Viewed_Property")
public class RecentlyViewedProperty {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long RecentlyViewedPropertyId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "propertyType_id")
    private PropertyType propertyType;
    @Column(name = "Viewed")
    private LocalDate viewedAt;

}
