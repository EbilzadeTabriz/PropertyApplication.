package www.Property.property.entity;

public enum Role {
    USER,
    ADMIN

}