package www.Property.property.exception;

public class Property1NotFound extends RuntimeException {
    public Property1NotFound(String message) {
        super(message);
    }
}
