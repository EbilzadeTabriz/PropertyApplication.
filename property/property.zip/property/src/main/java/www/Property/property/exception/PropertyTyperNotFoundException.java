package www.Property.property.exception;

public class PropertyTyperNotFoundException extends RuntimeException {
    public PropertyTyperNotFoundException(String message)  {
        super(message);
    }
}
