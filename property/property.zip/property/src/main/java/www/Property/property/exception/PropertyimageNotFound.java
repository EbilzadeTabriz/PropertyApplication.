package www.Property.property.exception;

public class PropertyimageNotFound extends RuntimeException {
    public PropertyimageNotFound(String message) {
    }
}
