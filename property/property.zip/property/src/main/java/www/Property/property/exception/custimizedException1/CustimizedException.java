package www.Property.property.exception.custimizedException1;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import www.Property.property.exception.ErrorDetails;

import java.time.LocalDateTime;
@Slf4j
@ControllerAdvice
public class CustimizedException  extends  ResponseEntityExceptionHandler {
    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllException(Exception ex, WebRequest request) throws Exception {
        ErrorDetails errorDetails = new ErrorDetails(LocalDateTime.now(),
                ex.getMessage(),
                request.getDescription(false));

        Object errormessage = "An error occurred:" + ex.getMessage() + LocalDateTime.now();


        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);

    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllException1(Exception ex, WebRequest request) throws Exception {
        ErrorDetails errorDetails = new ErrorDetails(LocalDateTime.now(),
                ex.getMessage(),
                request.getDescription(false));

        Object errormessage = "An error occurred:" + ex.getMessage() + LocalDateTime.now();
        return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);


    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllException2(Exception ex, WebRequest request) throws Exception {
        ErrorDetails errorDetails = new ErrorDetails(LocalDateTime.now(),
                ex.getMessage(),
                request.getDescription(false));

        Object errormessage = "An error occurred:" + ex.getMessage() + LocalDateTime.now();
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
