package www.Property.property.exception.custimizedException1;

public class NotificationNotFound  extends CustimizedException{
}
