package www.Property.property.exception.custimizedException1;

public class Property1NotFound extends CustimizedException{
}
