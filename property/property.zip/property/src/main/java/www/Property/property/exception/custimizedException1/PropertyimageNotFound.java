package www.Property.property.exception.custimizedException1;

public class PropertyimageNotFound extends CustimizedException {
}
