package www.Property.property.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import www.Property.property.entity.Property1;

import java.util.List;

//Property sehvlik var
@Repository
public interface Property1Repository extends JpaRepository<Property1,Long> {

    List<Property1> finByLocationAndPriceBetweeen(String name, String location, int minPrice, int maxPrice, int bedroomCount);
}
