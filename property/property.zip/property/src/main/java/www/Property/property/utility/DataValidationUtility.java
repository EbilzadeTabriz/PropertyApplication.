package www.Property.property.utility;

import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class DataValidationUtility {
    public static boolean isValidEmail(String email) {
        String pattern = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(email);
        boolean isValid = matcher.matches();

        if (isValid) {
            System.out.println("Email is valid");
        } else {
            System.out.println("Email is invalid");
        }

        return isValid;
    }

    public static boolean isValidPhoneNumber(String phoneNumber) {
        String pattern = "^\\+\\d{1,3} \\d{3} \\d{2} \\d{2}$";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(phoneNumber);
        boolean isValid = matcher.matches();

        if (isValid) {
            System.out.println("Phone number is valid");
        } else {
            System.out.println("Phone number is invalid");
        }

        return isValid;
    }

    public static void main(String[] args) {
        String emailSample = "black.night@gmail.com";
        String phoneNumberSample = "+994 255 25 25";

        isValidEmail(emailSample);
        isValidPhoneNumber(phoneNumberSample);
    }
}
