package www.Property.property.utility;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.io.*;
import java.nio.file.*;

public class ImageUploadUtility {

    public static void uploadImages(File sourceImage,String destinationPath) throws IOException{
        Path destination = Paths.get(destinationPath);
        if(!Files.exists(destination.getParent())){
            Files.createDirectories(destination.getParent());
        }
        Files.copy(sourceImage.toPath(),destination,StandardCopyOption.REPLACE_EXISTING);
    }

    public static void main(String[] args) {
        try {
            File sourceImage = new File("path_to_source_image.jpg");
            String destinationPath = "path_to_destination_folder/destination_image.jpg";
            uploadImages(sourceImage, destinationPath);
            System.out.println("Image uploaded successfully");
        }catch (IOException e){
            System.out.println("Error uploading image:" + e.getMessage());

        }
    }
}

