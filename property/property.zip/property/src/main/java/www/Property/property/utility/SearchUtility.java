package www.Property.property.utility;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import www.Property.property.entity.Property1;
import www.Property.property.repository.Property1Repository;

import java.util.List;

@Data
@RequiredArgsConstructor
public class SearchUtility {
    private final Property1Repository property1Repository;

    public List<Property1> searchPropertiesByCriteria(String name, String location, int minPrice, int maxPrice, int bedroomCount) {
        return property1Repository.finByLocationAndPriceBetweeen(name,location,minPrice,maxPrice,bedroomCount);
    }
}
